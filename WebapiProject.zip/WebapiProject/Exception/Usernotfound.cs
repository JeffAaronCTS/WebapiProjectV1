﻿namespace WebapiProject.Exception
{
    public class Usernotfound : ApplicationException
    {
        public Usernotfound() { }
        public Usernotfound(string msg) : base(msg) { }
    }
}
