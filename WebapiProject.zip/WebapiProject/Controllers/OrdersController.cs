﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebapiProject.Data;
using WebapiProject.Models;
using WebapiProject.Repository;

namespace WebapiProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;

        public OrderController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }
        //[Authorize(Roles = "User")]
        [HttpPost]
        public IActionResult PlaceOrder(Order order)
        {
            _orderRepository.PlaceOrder(order);
            return Ok("Order placed and stock updated successfully.");
        }
        //[Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public IActionResult UpdateOrderStatus(int id, [FromBody] string status)
        {
            _orderRepository.UpdateOrderStatus(id, status);
            return Ok("Order status updated successfully.");
        }
        //[Authorize(Roles = "Admin,User")]
        [HttpGet("{id}")]
        public IActionResult GetOrderById(int id)
        {
            var order = _orderRepository.GetOrderById(id);
            if (order == null)
            {
                return NotFound("Order not found.");
            }
            return Ok(order);
        }
        //[Authorize(Roles = "Admin,User")]
        [HttpGet]
        public IActionResult GetAllOrders()
        {
            var orders = _orderRepository.GetAllOrders();
            if (orders == null || !orders.Any())
            {
                return NotFound("No orders found.");
            }
            return Ok(orders);
        }
    }
}

