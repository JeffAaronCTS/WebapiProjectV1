﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebapiProject.Authentication;
using WebapiProject.Data;
using WebapiProject.Models;
using WebapiProject.Repository;

namespace WebapiProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProuductRepository _productRepository;

        public ProductsController(IProuductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        //[Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult AddProduct([FromBody] Product product)
        {
            if (product == null || !ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _productRepository.AddProduct(product);
            return Ok("Product added and stock updated successfully.");
        }
        //[Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(string id, [FromBody] Product product, long? quantityAdded = null)
        {
            if (product == null || !ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != product.ProductId)
            {
                return BadRequest("Product ID mismatch.");
            }

            _productRepository.UpdateProduct(product, quantityAdded);
            return Ok("Product updated and stock updated successfully.");
        }
        //[Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(string id)
        {
            _productRepository.DeleteProduct(id);
            return Ok("Product deleted successfully.");
        }
        //[Authorize(Roles = "Admin,User")]
        [HttpGet("ProductByID/{id}")]
        public IActionResult GetProductById(string id)
        {
            var product = _productRepository.GetProductById(id);
            if (product == null)
            {
                return NotFound("Product not found.");
            }
            return Ok(product);
        }
        
        //[Authorize(Roles ="Admin")]
        [HttpGet("ProductBySuppierID/{Sid}")]
        public IActionResult GetProductBySuppId(int Sid)
        {
            var product = _productRepository.GetProductBySupplier(Sid);
            if (product == null)
            {
                return NotFound("Product not found.");
            }
            return Ok(product);
        }

        //[Authorize(Roles = "Admin,User")]
        [HttpGet("ProductByCategory/{Category}")]

        public IActionResult GetlProductByCategory(string Category)
        {
            var products = _productRepository.GetProductByCategory(Category);
            if (products == null || !products.Any())
            {
                return NotFound("No products found.");
            }
            return Ok(products);
        }

        //[Authorize(Roles ="Admin,User")]
        [HttpGet]

        public IActionResult GetAllProducts()
        {
            var products = _productRepository.GetAllProducts();
            if (products == null || !products.Any())
            {
                return NotFound("No products found.");
            }
            return Ok(products);
        }
    }
}
