﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebapiProject.Models;
using WebapiProject.Repository;

namespace WebapiProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {
        private readonly IStockRepository _stockRepository;

        public StockController(IStockRepository stockRepository)
        {
            _stockRepository = stockRepository;
        }


        //[Authorize(Roles = "Admin")]
        [HttpGet("GetAllStock")]
        public IActionResult GetAllStock()
        {
            var stocks = _stockRepository.GetAllStock();
            if (stocks.Count > 0)
            {
                return Ok(stocks);
            }
            else
            {
                return NotFound("No stock details found.");
            }
        }
        [HttpPost("AddStock")]
        public IActionResult AddStock(string productId, int quantity)
        {
            _stockRepository.AddStock(productId, quantity);
            return Ok("Stock added successfully.");

        }
    }
}