﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebapiProject.Repository;

namespace WebapiProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportRepository _reportRepository;

        public ReportController(IReportRepository reportRepository)
        {
            _reportRepository = reportRepository;
        }
       
        [HttpGet("GenerateInventoryReport")]
        public IActionResult GenerateInventoryReport(DateTime startDate, DateTime endDate, string format)
        {
            var report = _reportRepository.GenerateInventoryReport(startDate, endDate);

            if (format.ToLower() == "json")
            {
                var json = JsonSerializer.Serialize(report);
                return File(new MemoryStream(Encoding.UTF8.GetBytes(json)), "application/json", "InventoryReport.json");
            }
            else if (format.ToLower() == "pdf")
            {
                var pdf = GeneratePdfReport(report, "Inventory Report");
                return File(pdf, "application/pdf", "InventoryReport.pdf");
            }
            else
            {
                return BadRequest("Invalid format specified.");
            }
        }
        //[Authorize(Roles = "Admin,User")]
        [HttpGet("GenerateOrderReport")]
        public IActionResult GenerateOrderReport(DateTime startDate, DateTime endDate, string format)
        {
            var report = _reportRepository.GenerateOrderReport(startDate, endDate);

            if (format.ToLower() == "json")
            {
                var json = JsonSerializer.Serialize(report);
                return File(new MemoryStream(Encoding.UTF8.GetBytes(json)), "application/json", "OrderReport.json");
            }
            else if (format.ToLower() == "pdf")
            {
                var pdf = GeneratePdfReport(report, "Order Report");
                return File(pdf, "application/pdf", "OrderReport.pdf");
            }
            else
            {
                return BadRequest("Invalid format specified.");
            }
        }
        //[Authorize(Roles = "Admin")]
        [HttpGet("GenerateLowStockItemsReport")]
        public IActionResult GenerateLowStockItemsReport(string format)
        {
            var report = _reportRepository.GenerateLowStockItemsReport();

            if (format.ToLower() == "json")
            {
                var json = JsonSerializer.Serialize(report);
                return File(new MemoryStream(Encoding.UTF8.GetBytes(json)), "application/json", "LowStockItemsReport.json");
            }
            else if (format.ToLower() == "pdf")
            {
                var pdf = GeneratePdfReport(report, "Low Stock Items Report");
                return File(pdf, "application/pdf", "LowStockItemsReport.pdf");
            }
            else
            {
                return BadRequest("Invalid format specified.");
            }
        }
        [Authorize(Roles = "Admin")]
        private byte[] GeneratePdfReport(IEnumerable<object> report, string title)
        {
            using (var ms = new MemoryStream())
            {
                var document = new Document();
                PdfWriter.GetInstance(document, ms);
                document.Open();

                document.Add(new Paragraph(title));
                document.Add(new Paragraph("Generated on: " + DateTime.Now.ToString()));

                foreach (var item in report)
                {
                    document.Add(new Paragraph(item.ToString()));
                }

                document.Close();
                return ms.ToArray();
            }
        }
    }
}