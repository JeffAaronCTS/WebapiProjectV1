﻿namespace WebapiProject.Models
{
    public class LowStockItemsReport
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int AvailableQuantity { get; set; }
    }
}
