﻿namespace WebapiProject.Models
{
    public class MostOrderedProductReport
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int TotalOrders { get; set; }
    }
}
