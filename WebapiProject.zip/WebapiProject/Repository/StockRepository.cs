﻿using Microsoft.EntityFrameworkCore;
using WebapiProject.Models;

namespace WebapiProject.Repository
{
    public class StockRepository : IStockRepository
    {
        private readonly ApplicationDbContext db;

        public StockRepository(ApplicationDbContext db)
        {
            this.db = db;
        }


        public List<Stock> GetAllStock()
        {
            var stocks = db.Stocks.ToList();
            if (stocks == null || !stocks.Any())
            {
                throw new System.Exception("No stock data found.");
            }

            return stocks;
        }
        public void AddStock(string productId, int quantity)
        {
            db.Database.ExecuteSqlRaw(
                "EXEC AddStock @ProductId = {0}, @QuantityAdded = {1}",
                productId, quantity
            );
        }
    }
}