﻿using WebapiProject.Models;

namespace WebapiProject.Repository
{
    public interface IStockRepository
    {
        void AddStock(string productId, int quantity);
        List<Stock> GetAllStock();
    }
}