﻿using WebapiProject.Models;

namespace WebapiProject.Repository
{
    public interface IReportRepository
    {
        IEnumerable<object> GenerateInventoryReport(DateTime startDate, DateTime endDate);
        IEnumerable<object> GenerateOrderReport(DateTime startDate, DateTime endDate);
        IEnumerable<object> GenerateLowStockItemsReport();
    }
}
