﻿using WebapiProject.Models;
using Microsoft.EntityFrameworkCore;

namespace WebapiProject.Repository
{
    public class ReportRepository : IReportRepository
    {
        private readonly ApplicationDbContext db;

        public ReportRepository(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IEnumerable<object> GenerateInventoryReport(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
            {
                throw new System.Exception("Start date cannot be later than end date.");
            }

            // Execute the raw SQL query and get the result set
            var stockReport = db.Stocks
                .FromSqlRaw("EXEC GenerateInventoryReport @StartDate = {0}, @EndDate = {1}", startDate, endDate)
                .AsEnumerable() // Convert to IEnumerable to perform LINQ operations in memory
                .ToList();

            // Join the result set with the Products table to get the product name
            var report = stockReport
                .Join(db.Products,
                      stock => stock.ProductId,
                      product => product.ProductId,
                      (stock, product) => new
                      {
                          stock.StockId,
                          stock.ProductId,
                          ProductName = product.ProductName,
                          
                          stock.TotalStock,
                          stock.Date
                      })
                .ToList();

            if (report == null || !report.Any())
            {
                throw new System.Exception("No inventory data found for the given date range.");
            }

            return report;
        }
        public IEnumerable<object> GenerateOrderReport(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
            {
                throw new System.Exception("Start date cannot be later than end date.");
            }

            var report = db.Orders
                .FromSqlRaw("EXEC GenerateOrderReport @StartDate = {0}, @EndDate = {1}", startDate, endDate)
                .Select(o => new
                {
                    o.OrderId,
                    o.OrderDate,
                    o.ProductId,
                    ProductName = "Product Name", // Replace with actual product name lookup
                    o.OrderedQuantity
                })
                .ToList();

            if (report == null || !report.Any())
            {
                throw new System.Exception("No order data found for the given date range.");
            }

            return report;
        }

        public IEnumerable<object> GenerateLowStockItemsReport()
        {
            var report = db.Stocks
                .FromSqlRaw("EXEC GenerateLowStockItemsReport")
                .Select(s => new
                {
                    s.ProductId,
                    ProductName = "Product Name", // Replace with actual product name lookup
                    s.TotalStock
                })
                .ToList();

            if (report == null || !report.Any())
            {
                throw new System.Exception("No low stock items found.");
            }

            return report;
        }

        public object GenerateMostOrderedProductReport(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
            {
                throw new System.Exception("Start date cannot be later than end date.");
            }

            var report = db.Orders
                .FromSqlRaw("EXEC GenerateMostOrderedProductReport @StartDate = {0}, @EndDate = {1}", startDate, endDate)
                .Select(o => new
                {
                    o.ProductId,
                    TotalOrdered = o.OrderedQuantity // Adjust as needed based on your stored procedure's output
                })
                .FirstOrDefault();

            if (report == null)
            {
                throw new System.Exception("No order data found for the given date range.");
            }

            return report;
        }
    }
}